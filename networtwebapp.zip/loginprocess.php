<?php 

if(isset($_POST["loginapp"])){
	function validateForm($info){
	$info = trim($info);
	$info = stripslashes($info);
	$info = htmlspecialchars($info);
	$info = strip_tags($info);
	
	return $info;
}
	
	if(empty($_POST["loginemail"])){
		$form_email_error = "email required";
	}else{
		$login_email = validateForm($_POST["loginemail"]);
	}
	
	if(empty($_POST["loginpassword"])){
		$form_password_error = "password required";
	}else{
		$login_password = validateForm($_POST["loginpassword"]);
	}
	
			

	$query8 = "SELECT * FROM signup WHERE email = '$login_email'";
	//$query2 = "SELECT * FROM team_members WHERE email = '$email'";
	
	$result8 = mysqli_query($conn, $query8);
	//$result2 = mysqli_query($conn, $query2);
	
	if(mysqli_num_rows($result8) > 0){
		
		while($rows = mysqli_fetch_assoc($result8) ){
			$inuser			= $rows['first_name'];
			$email_log		= $rows['email'];
			$hashedPassword		= $rows['password'];	
		}
		if(password_verify($login_password, $hashedPassword)){
			session_start();
			$_SESSION["loggedin_emails"] = $email_log;
			$_SESSION["loggedin_first_name"] = $inuser;
			
			header("Location: asset.html");
		}else{
			$form_password_error = "wrong password";
		}
	
		
	}else{
		$form_email_error = "wrong email";
	}
			
}


?>