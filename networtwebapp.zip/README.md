TASK
Net worth calculator (Web)
A calculator that takes in assets and cash details, and calculate how much the user is worth
User sign up
User sign in
User enter asset
User enter Cash
User enter liability
App calculates total networth of user at that time