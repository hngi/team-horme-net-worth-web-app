<?php 
include("connection.php");
include("loginprocess.php");

include("signupprocess.php");



?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Net-Worth Calculator</title>
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="main.css" />
    </head>
    <body>
        <!-- Sign-in page -->
        <div class="container-fluid">
            <div
                class="row float-sm-right p-5"
                style="min-height: 100vh; background-color: black;"
            >
                <div class=" align-self-center text-center">
                    <h4 class="text-light mb-5">Already have an account?</h4>
                    <form action="<?php echo htmlspecialchars( $_SERVER["PHP_SELF"] ); ?>" method="post">
                        <div class="row">
                            <div class="col">
                                <div class="form-group m-3">
                                   <small style="color: red;"><?php echo $form_email_error; ?></small>
                                    <input
                                        type="text"
                                        name="loginemail"
                                        id="username"
                                        placeholder="Email"
                                        class="p-4 form-control form-control-lg color"
                                        style="border: 0; border-bottom: 2px solid yellow; border-radius:0; background-color: transparent; color:yellow;"
                                    />
                                </div>
                                <div class="form-group m-3">
                                     <small style="color: red;"><?php echo $form_password_error; ?></small>

                                    <input
                                        type="password"
                                        name="loginpassword"
                                        id="password1"
                                        placeholder="Password"
                                        class="p-4 form-control form-control-lg color"
                                        style="border: 0; border-bottom: 2px solid yellow; border-radius:0; background-color: transparent; color:yellow;"
                                       
                                    />
                                </div>
                                <div class="form-group p-3">
                                    <input
                                        type="checkbox"
                                        name="checkbox"
                                        id="checkbox"
                                    /><span
                                        class="font-weight-bold text-light pl-1"
                                        >Remember me</span
                                    >
                                </div>
                                <div class="form-group pt-3">
                                    <input
                                        type="submit"
                                        name="loginapp"
                                        id="submit"
                                        value="Login"
                                        class="p-2 btn btn-warning text-light font-weight-bold col-9"
                                        style="border-radius: 50px; color: yellow"
                                    />
                                    <a href="#" class="text-warning"
                                        ><p>Forgot password?</p></a
                                    >
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row pt-2" style="min-height: 100vh;" id="page">
                <div class="col col-md-12 align-self-center text-center">
                    <h4
                        class="mt-3 ml-5 text-left text-warning"
                        style="color: yellow"
                    >
                        REGISTER HERE
                    </h4>
                    <form action="<?php echo htmlspecialchars( $_SERVER["PHP_SELF"] ); ?>" method="post" class="justify-content-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                   <small style="color: red;"><?php echo $first_name_error; ?></small>
                                    <input
                                        type="text"
                                        name="firstname"
                                        id="name"
                                        placeholder=" First name"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                    <small style="color: red;"><?php echo $last_name_error; ?></small>
                                    <input
                                        type="text"
                                        name="lastname"
                                        id="secondName"
                                        placeholder="Last Name"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                    <small style="color: red;"><?php echo $email_error; ?></small>
                                    <input
                                        type="text"
                                        name="email"
                                        id="email"
                                        placeholder="Email Address"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                    <small style="color: red;"><?php echo $phone_error; ?></small>
                                    <input
                                        type="text"
                                        name="phone"
                                        id="phone"
                                        placeholder="Enter Your Phone Number"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                    <small style="color: red;"><?php echo $password_error; ?></small>
                                    <input
                                        type="password"
                                        name="password"
                                        id="password"
                                        placeholder="Choose your password"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group m-5">
                                    <small style="color: red;"><?php echo $confirm_password_error; ?></small>
                                    <input
                                        type="password"
                                        name="confirmpassword"
                                        id="confirmpassword"
                                        placeholder="Confirm password"
                                        class="p-4 form-control form-control-lg color pl-5"
                                        style="border: 0; border-bottom: 2px solid black; border-radius:0; background-color: transparent"
                                        
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="form-group p-3">
                            <input
                                type="checkbox"
                                name="checkbox"
                                id="checkbox"
                                
                            /><span class="font-weight-bold ml-1"
                                >I Agree To The Terms And Conditions</span
                            >
                        </div>
                        <div class="form-group p-2">
                            <input
                                type="submit"
                                name="sign_up"
                                id="submit"
                                value="REGISTER NOW"
                                class="p-2 btn btn-warning col-8 col-md-3 text-light font-weight-bold"
                                style="border-radius: 50px; color: yellow"
                            />
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="./app.js"></script>
    </body>
</html>
