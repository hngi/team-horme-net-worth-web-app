<?php


//SIGN UP PROCESS
if(isset($_POST["sign_up"])){
	
	function validateFormData($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	$data = strip_tags($data);
	
	return $data;
}
	
		$first_name_check = validateFormData($_POST["firstname"]);
		$last_name_check = validateFormData($_POST["lastname"]);
		$email_check = validateFormData($_POST["email"]);
		$phone_check = validateFormData($_POST["phone"]);
		$password_check = validateFormData($_POST["password"]);
		$confirm_password_check = validateFormData($_POST["confirmpassword"]);
		
	
		//checking the name format
		if(!preg_match("/^[A-Za-z]+$/", $first_name_check) && $first_name_check){
			$first_name_error = "Use only alphabets";
		} else if(empty($first_name_check)){
		$first_name_error = "You can't leave this field empty";
	}else{
		$first_name = validateFormData($_POST["firstname"]);
	}
	
	//checking the name format
		if(!preg_match("/^[A-Za-z]+$/", $last_name_check) && $last_name_check){
			$last_name_error = "Use only alphabets";
		} else if(empty($last_name_check)){
		$last_name_error = "You can't leave this field empty";
	}else{
		$last_name = validateFormData($_POST["lastname"]);
	}

	//checking the phone number format
		if(!preg_match("/[0-9]{11}/", $phone_check) && $phone_check){
			$phone_error = "Use only 11 or more numbers";
		} else if(empty($phone_check)){
		$phone_error = "You can't leave this field empty";
	}else{
		$phone = validateFormData($_POST["phone"]);
	}
		 
    	// checking if it is a valid email
    	if(!filter_var($email_check, FILTER_VALIDATE_EMAIL) && $email_check) {
      		$email_error = "Invalid email format"; 
    	}if(empty($email_check)) {
    	$email_error = "Email is required";
    }else {
		 $email = validateFormData($_POST["email"]);
  	}
	
	if($confirm_password_check !== $password_check){
		$confirm_password_error = "password does not match";
		$password_error = "password does not match";
	}
	
	
	if(empty($_POST["password"])){
		$password_error = "You can't leave this field empty";
	}else{
		$password = password_hash( validateFormData($_POST['password']), PASSWORD_DEFAULT );
	}
	
	if(empty($_POST["confirmpassword"])){
		$confirm_password_error = "You can't leave this field empty";
	}else{
		$confirm_password = password_hash( validateFormData($_POST['confirmpassword']), PASSWORD_DEFAULT );
	}
	

	$query2 = "SELECT * FROM signup WHERE email = '$email'";
	
	$result2 = mysqli_query($conn, $query2);
	
	if(mysqli_num_rows($result2) > 0){
		$email_error = "This email has been taken";		
	}
	
	
		if($password_check === $confirm_password_check && $email && $phone && $first_name && last_name && mysqli_num_rows($result2) < 1){
		$query = "INSERT INTO signup (id, first_name, last_name, email, phone, password, confirm_password, signup_date
)
		
				   VALUES (NULL, '$first_name', '$last_name', '$email', '$phone', '$password', '$confirm_password',  CURRENT_TIMESTAMP)";
		
		if(mysqli_query($conn, $query)){
			$success= "Thanks! you can now use the app click <a href ='#'>HERE</a>";
			echo $success;
		}else{
			
		echo "Errror:" . $query . "<br>" .mysqli_error($conn);

		}
	}
	

}



//LOGIN PROCESS
	
mysqli_close($conn);
 

?>




























































